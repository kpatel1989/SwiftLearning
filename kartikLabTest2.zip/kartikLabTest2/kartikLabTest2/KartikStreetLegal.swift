//
//  KartikStreetLegal.swift
//  kartikLabTest2
//
//  Created by macadmin on 2016-10-12.
//  Copyright © 2016 LambtonCollege. All rights reserved.
//

import Cocoa

protocol KartikStreetLegal {
    func kartikSignalStop()
    func kartikSignalLeftTurn()
    func kartikSignalRightTurn()
}
